"use client";

import { useState } from "react";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

const courses = ["Frontend", "Python Backend", "Foundation", "Grafik dizayn"];

export default function Home() {
  const [form, setForm] = useState({ name: "", phone: "", course: "Frontend", message: "" });
  const [status, setStatus] = useState("");

  async function submitLead(e: React.FormEvent) {
    e.preventDefault();
    setStatus("Yuborilmoqda...");
    try {
      const res = await fetch(`${API_URL}/api/leads`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error("Xatolik yuz berdi");
      setStatus("Arizangiz qabul qilindi. Tez orada bog‘lanamiz!");
      setForm({ name: "", phone: "", course: "Frontend", message: "" });
    } catch {
      setStatus("Serverga ulanishda xatolik. Keyinroq urinib ko‘ring.");
    }
  }

  return (
    <main className="overflow-hidden">
      <section className="relative bg-slate-950 text-white">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,#22c55e33,transparent_35%),radial-gradient(circle_at_top_left,#38bdf833,transparent_30%)]" />
        <nav className="relative mx-auto flex max-w-7xl items-center justify-between px-6 py-6">
          <div className="text-2xl font-black">EduLead</div>
          <div className="hidden gap-6 text-sm text-slate-300 md:flex">
            <a href="#courses">Kurslar</a>
            <a href="#price">Narxlar</a>
            <a href="#contact">Ariza</a>
          </div>
          <a href="#contact" className="rounded-full bg-emerald-400 px-5 py-3 text-sm font-bold text-slate-950">
            Bepul konsultatsiya
          </a>
        </nav>

        <div className="relative mx-auto grid max-w-7xl gap-12 px-6 pb-24 pt-16 lg:grid-cols-2 lg:items-center">
          <div>
            <div className="mb-5 inline-flex rounded-full border border-white/10 bg-white/10 px-4 py-2 text-sm text-emerald-200">
              3 oyda amaliy kasbga start
            </div>
            <h1 className="text-5xl font-black leading-tight md:text-7xl">
              IT kurslar uchun zamonaviy landing sahifa
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-8 text-slate-300">
              Ushbu demo o‘quv markazlar uchun tayyorlangan: kurslar, narxlar,
              savol-javoblar va ariza qabul qilish backend bilan ishlaydi.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <a href="#contact" className="rounded-2xl bg-emerald-400 px-7 py-4 text-center font-black text-slate-950">
                Ariza qoldirish
              </a>
              <a href="/admin" className="rounded-2xl border border-white/15 px-7 py-4 text-center font-bold">
                Admin demo
              </a>
            </div>
          </div>

          <div className="rounded-[2rem] border border-white/10 bg-white/10 p-5 shadow-soft backdrop-blur">
            <div className="rounded-[1.5rem] bg-white p-6 text-slate-950">
              <div className="mb-5 flex items-center justify-between">
                <h3 className="text-xl font-black">Bugungi statistika</h3>
                <span className="rounded-full bg-emerald-100 px-3 py-1 text-sm text-emerald-700">Live demo</span>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                {[
                  ["128", "Yangi arizalar"],
                  ["42", "Qo‘ng‘iroq kutilmoqda"],
                  ["17", "To‘lov qilganlar"],
                  ["89%", "Konversiya sifati"],
                ].map(([n, t]) => (
                  <div key={t} className="rounded-3xl bg-slate-100 p-5">
                    <p className="text-3xl font-black">{n}</p>
                    <p className="mt-1 text-sm text-slate-500">{t}</p>
                  </div>
                ))}
              </div>
              <div className="mt-5 rounded-3xl bg-slate-950 p-5 text-white">
                <p className="font-bold">Backend imkoniyati:</p>
                <p className="mt-2 text-sm text-slate-300">
                  Forma FastAPI serverga yuboriladi, SQLite bazaga saqlanadi,
                  admin panel orqali ko‘riladi.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="courses" className="mx-auto max-w-7xl px-6 py-20">
        <div className="mb-10 max-w-2xl">
          <h2 className="text-4xl font-black">Kurslar</h2>
          <p className="mt-3 text-slate-600">Landing istalgan o‘quv markazga moslab beriladi.</p>
        </div>
        <div className="grid gap-5 md:grid-cols-4">
          {courses.map((course) => (
            <div key={course} className="rounded-3xl border bg-white p-6 shadow-sm">
              <div className="mb-8 h-24 rounded-2xl bg-gradient-to-br from-slate-100 to-emerald-100" />
              <h3 className="text-xl font-black">{course}</h3>
              <p className="mt-2 text-sm leading-6 text-slate-600">
                Amaliy topshiriqlar, mentor nazorati va portfolio loyihalar.
              </p>
            </div>
          ))}
        </div>
      </section>

      <section id="price" className="bg-white py-20">
        <div className="mx-auto max-w-7xl px-6">
          <h2 className="text-4xl font-black">Narxlar</h2>
          <div className="mt-8 grid gap-5 md:grid-cols-3">
            {[
              ["Start", "490 000 so‘m", "1 ta kurs sahifasi + forma"],
              ["Business", "990 000 so‘m", "Admin panel + arizalar bazasi"],
              ["Pro", "1 900 000 so‘m", "Telegram xabar + moslashtirish"],
            ].map(([name, price, desc]) => (
              <div key={name} className="rounded-3xl border p-7">
                <h3 className="text-2xl font-black">{name}</h3>
                <p className="mt-4 text-3xl font-black">{price}</p>
                <p className="mt-3 text-slate-600">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="mx-auto grid max-w-7xl gap-10 px-6 py-20 lg:grid-cols-2">
        <div>
          <h2 className="text-4xl font-black">Ariza qoldiring</h2>
          <p className="mt-4 text-lg leading-8 text-slate-600">
            Bu forma real backendga ulanadi. Sotiladigan template sifatida eng muhim qismi shu.
          </p>
          <div className="mt-8 rounded-3xl bg-slate-950 p-6 text-white">
            <p className="font-bold">Demo admin:</p>
            <p className="mt-2 text-slate-300">/admin sahifasiga kiring va token sifatida <b>demo-admin-token</b> yozing.</p>
          </div>
        </div>

        <form onSubmit={submitLead} className="rounded-[2rem] bg-white p-6 shadow-soft">
          <div className="grid gap-4">
            <input
              required
              className="rounded-2xl border px-4 py-4 outline-none focus:border-emerald-500"
              placeholder="Ismingiz"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
            <input
              required
              className="rounded-2xl border px-4 py-4 outline-none focus:border-emerald-500"
              placeholder="Telefon raqamingiz"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
            />
            <select
              className="rounded-2xl border px-4 py-4 outline-none focus:border-emerald-500"
              value={form.course}
              onChange={(e) => setForm({ ...form, course: e.target.value })}
            >
              {courses.map((c) => <option key={c}>{c}</option>)}
            </select>
            <textarea
              className="min-h-32 rounded-2xl border px-4 py-4 outline-none focus:border-emerald-500"
              placeholder="Qo‘shimcha izoh"
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
            />
            <button className="rounded-2xl bg-slate-950 px-6 py-4 font-black text-white">
              Yuborish
            </button>
            {status && <p className="text-sm font-semibold text-emerald-700">{status}</p>}
          </div>
        </form>
      </section>

      <footer className="bg-slate-950 px-6 py-10 text-center text-slate-400">
        EduLead demo template — Next.js + FastAPI
      </footer>
    </main>
  );
}
